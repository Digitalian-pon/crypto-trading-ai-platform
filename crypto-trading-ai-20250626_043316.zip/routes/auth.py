import os
import logging
from flask import Blueprint, request, render_template, redirect, url_for, flash, session
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from app import db
from models import User, TradingSettings

logger = logging.getLogger(__name__)

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard.index'))
        
    if request.method == 'POST':
        # Check if it's username/password login or API credentials login
        username = request.form.get('username')
        password = request.form.get('password')
        api_key = request.form.get('api_key')
        api_secret = request.form.get('api_secret')
        remember = True if request.form.get('remember') else False
        
        # Username/Password login
        if username and password:
            user = User.query.filter_by(username=username).first()
            
            if user and user.check_password(password):
                login_user(user, remember=remember)
                flash('Login successful!', 'success')
                next_page = request.args.get('next')
                # ダッシュボードへの直接アクセスを許可
                session['user_authenticated'] = True
                session['user_id'] = user.id
                return redirect('/dashboard')
            else:
                flash('Invalid username or password', 'danger')
                return render_template('login.html')
        
        # API credentials login
        elif api_key and api_secret:
            # Import here to avoid circular imports
            from config import save_api_credentials
            from services.gmo_api import GMOCoinAPI
            
            # Verify credentials by making a test API call
            api = GMOCoinAPI(api_key, api_secret)
            result = api.get_ticker()
            
            if not result or 'error' in result:
                flash('Invalid API credentials or API connection failed', 'danger')
                return render_template('login.html')
            
            # Credentials are valid, check if user exists
            user = User.query.filter_by(api_key=api_key).first()
            
            if not user:
                # Create a new user with these API credentials
                username = f"user_{api_key[:8]}"  # Create a username based on API key
                email = f"{username}@example.com"  # Create a dummy email
                
                # Check if username exists (very unlikely, but just in case)
                existing_user = User.query.filter_by(username=username).first()
                if existing_user:
                    username = f"user_{api_key[:12]}"  # Use a longer part of API key
                    
                # Create the user
                user = User()
                user.username = username
                user.email = email
                user.api_key = api_key
                user.api_secret = api_secret
                user.set_password('dummy_password')  # Not used but needed for the model
                
                try:
                    db.session.add(user)
                    db.session.commit()
                    
                    # Create default trading settings for the user
                    default_settings = TradingSettings(
                        user_id=user.id,
                        currency_pair='DOGE_JPY',
                        trading_enabled=False,
                        investment_amount=0.0,
                        risk_level='medium',
                        stop_loss_percentage=3.0,
                        take_profit_percentage=5.0
                    )
                    db.session.add(default_settings)
                    db.session.commit()
                    
                    logger.info(f"Created new user with API credentials: {username}")
                except Exception as e:
                    db.session.rollback()
                    logger.error(f"Error creating user with API credentials: {e}")
                    flash('Error creating user profile', 'danger')
                    return render_template('login.html')
            else:
                # Update API credentials if they've changed
                if user.api_secret != api_secret:
                    user.api_secret = api_secret
                    db.session.commit()
            
            # Save credentials to setting.ini
            save_api_credentials(api_key, api_secret)
            
            # Log the user in
            login_user(user, remember=remember)
            flash('Login successful!', 'success')
            next_page = request.args.get('next')
            return redirect(next_page or url_for('dashboard.index'))
        
        else:
            flash('Please enter either username/password or API credentials', 'danger')
            return render_template('login.html')
            
    return render_template('login.html')

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    # Registration is disabled since we're using API credentials instead
    flash('Registration is disabled. Please login with your GMO Coin API credentials.', 'info')
    return redirect(url_for('auth.login'))

@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out', 'info')
    return redirect(url_for('auth.login'))

@auth_bp.route('/')
def index():
    # Serve DOGE/JPY dashboard directly without authentication redirects
    return render_template('vps_index.html')
