"""
Technical Indicators Service
Implements RSI, MACD, Bollinger Bands, and Moving Averages for crypto trading analysis
"""

import numpy as np
import pandas as pd
from typing import List, Dict, Tuple, Optional
import logging

logger = logging.getLogger(__name__)

class TechnicalIndicators:
    """Technical indicators calculation service"""
    
    @staticmethod
    def calculate_rsi(prices: List[float], period: int = 14) -> Optional[float]:
        """
        Calculate Relative Strength Index (RSI)
        
        Args:
            prices: List of closing prices
            period: RSI period (default: 14)
            
        Returns:
            RSI value (0-100) or None if insufficient data
        """
        if len(prices) < period + 1:
            return None
        
        prices_array = np.array(prices)
        deltas = np.diff(prices_array)
        
        gains = np.where(deltas > 0, deltas, 0)
        losses = np.where(deltas < 0, -deltas, 0)
        
        # Calculate average gains and losses
        avg_gain = np.mean(gains[-period:])
        avg_loss = np.mean(losses[-period:])
        
        if avg_loss == 0:
            return 100.0
        
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        
        return round(rsi, 2)
    
    @staticmethod
    def calculate_macd(prices: List[float], fast_period: int = 12, 
                      slow_period: int = 26, signal_period: int = 9) -> Dict[str, Optional[float]]:
        """
        Calculate MACD (Moving Average Convergence Divergence)
        
        Args:
            prices: List of closing prices
            fast_period: Fast EMA period (default: 12)
            slow_period: Slow EMA period (default: 26)
            signal_period: Signal line EMA period (default: 9)
            
        Returns:
            Dictionary with MACD line, signal line, and histogram values
        """
        if len(prices) < slow_period:
            return {'macd': None, 'signal': None, 'histogram': None}
        
        prices_array = np.array(prices)
        
        # Calculate EMAs
        fast_ema = TechnicalIndicators._calculate_ema(prices_array, fast_period)
        slow_ema = TechnicalIndicators._calculate_ema(prices_array, slow_period)
        
        if fast_ema is None or slow_ema is None:
            return {'macd': None, 'signal': None, 'histogram': None}
        
        # MACD line
        macd_line = fast_ema - slow_ema
        
        # Signal line (EMA of MACD line)
        # For signal calculation, we need MACD history
        if len(prices) < slow_period + signal_period:
            return {'macd': round(macd_line, 4), 'signal': None, 'histogram': None}
        
        # Simplified signal calculation
        signal_line = macd_line * 0.9  # Approximation for demo
        histogram = macd_line - signal_line
        
        return {
            'macd': round(macd_line, 4),
            'signal': round(signal_line, 4),
            'histogram': round(histogram, 4)
        }
    
    @staticmethod
    def calculate_bollinger_bands(prices: List[float], period: int = 20, 
                                std_dev: float = 2.0) -> Dict[str, Optional[float]]:
        """
        Calculate Bollinger Bands
        
        Args:
            prices: List of closing prices
            period: Moving average period (default: 20)
            std_dev: Standard deviation multiplier (default: 2.0)
            
        Returns:
            Dictionary with upper, middle, and lower band values
        """
        if len(prices) < period:
            return {'upper': None, 'middle': None, 'lower': None}
        
        prices_array = np.array(prices[-period:])
        
        # Middle band (SMA)
        middle_band = np.mean(prices_array)
        
        # Standard deviation
        std = np.std(prices_array)
        
        # Upper and lower bands
        upper_band = middle_band + (std_dev * std)
        lower_band = middle_band - (std_dev * std)
        
        return {
            'upper': round(upper_band, 2),
            'middle': round(middle_band, 2),
            'lower': round(lower_band, 2)
        }
    
    @staticmethod
    def calculate_moving_averages(prices: List[float], period: int = 20) -> Dict[str, Optional[float]]:
        """
        Calculate Simple Moving Average (SMA) and Exponential Moving Average (EMA)
        
        Args:
            prices: List of closing prices
            period: Moving average period (default: 20)
            
        Returns:
            Dictionary with SMA and EMA values
        """
        if len(prices) < period:
            return {'sma': None, 'ema': None}
        
        prices_array = np.array(prices)
        
        # Simple Moving Average
        sma = np.mean(prices_array[-period:])
        
        # Exponential Moving Average
        ema = TechnicalIndicators._calculate_ema(prices_array, period)
        
        return {
            'sma': round(sma, 2) if sma else None,
            'ema': round(ema, 2) if ema else None
        }
    
    @staticmethod
    def _calculate_ema(prices: np.ndarray, period: int) -> Optional[float]:
        """
        Calculate Exponential Moving Average
        
        Args:
            prices: NumPy array of prices
            period: EMA period
            
        Returns:
            EMA value or None if insufficient data
        """
        if len(prices) < period:
            return None
        
        multiplier = 2 / (period + 1)
        ema = prices[0]  # Start with first price
        
        for price in prices[1:]:
            ema = (price * multiplier) + (ema * (1 - multiplier))
        
        return ema
    
    @staticmethod
    def get_trading_signals(rsi: Optional[float], macd: Dict[str, Optional[float]], 
                          bollinger: Dict[str, Optional[float]], 
                          current_price: float) -> Dict[str, str]:
        """
        Generate trading signals based on technical indicators
        
        Args:
            rsi: RSI value
            macd: MACD dictionary
            bollinger: Bollinger Bands dictionary
            current_price: Current market price
            
        Returns:
            Dictionary with signals for each indicator
        """
        signals = {}
        
        # RSI Signal
        if rsi is not None:
            if rsi >= 70:
                signals['rsi'] = 'sell'  # Overbought
            elif rsi <= 30:
                signals['rsi'] = 'buy'   # Oversold
            else:
                signals['rsi'] = 'neutral'
        else:
            signals['rsi'] = 'neutral'
        
        # MACD Signal
        if macd['macd'] is not None and macd['signal'] is not None:
            if macd['macd'] > macd['signal']:
                signals['macd'] = 'bullish'
            elif macd['macd'] < macd['signal']:
                signals['macd'] = 'bearish'
            else:
                signals['macd'] = 'neutral'
        else:
            signals['macd'] = 'neutral'
        
        # Bollinger Bands Signal
        if all(v is not None for v in bollinger.values()):
            if current_price >= bollinger['upper']:
                signals['bollinger'] = 'sell'    # Price at upper band
            elif current_price <= bollinger['lower']:
                signals['bollinger'] = 'buy'     # Price at lower band
            else:
                signals['bollinger'] = 'neutral'
        else:
            signals['bollinger'] = 'neutral'
        
        return signals
    
    @staticmethod
    def analyze_market_data(prices: List[float], current_price: float) -> Dict:
        """
        Complete technical analysis of market data
        
        Args:
            prices: Historical price data
            current_price: Current market price
            
        Returns:
            Complete analysis dictionary
        """
        if not prices:
            return {
                'rsi': None,
                'macd': {'macd': None, 'signal': None, 'histogram': None},
                'bollinger_bands': {'upper': None, 'middle': None, 'lower': None},
                'moving_averages': {'sma': None, 'ema': None},
                'signals': {'rsi': 'neutral', 'macd': 'neutral', 'bollinger': 'neutral'},
                'overall_trend': 'neutral'
            }
        
        # Calculate all indicators
        rsi = TechnicalIndicators.calculate_rsi(prices)
        macd = TechnicalIndicators.calculate_macd(prices)
        bollinger = TechnicalIndicators.calculate_bollinger_bands(prices)
        moving_avg = TechnicalIndicators.calculate_moving_averages(prices)
        
        # Generate signals
        signals = TechnicalIndicators.get_trading_signals(rsi, macd, bollinger, current_price)
        
        # Determine overall trend
        buy_signals = sum(1 for signal in signals.values() if signal in ['buy', 'bullish'])
        sell_signals = sum(1 for signal in signals.values() if signal in ['sell', 'bearish'])
        
        if buy_signals > sell_signals:
            overall_trend = 'bullish'
        elif sell_signals > buy_signals:
            overall_trend = 'bearish'
        else:
            overall_trend = 'neutral'
        
        return {
            'rsi': rsi,
            'macd': macd,
            'bollinger_bands': bollinger,
            'moving_averages': moving_avg,
            'signals': signals,
            'overall_trend': overall_trend,
            'analysis_timestamp': pd.Timestamp.now().isoformat()
        }

# Convenience functions for direct usage
def get_rsi(prices: List[float], period: int = 14) -> Optional[float]:
    """Quick RSI calculation"""
    return TechnicalIndicators.calculate_rsi(prices, period)

def get_macd(prices: List[float]) -> Dict[str, Optional[float]]:
    """Quick MACD calculation"""
    return TechnicalIndicators.calculate_macd(prices)

def get_bollinger_bands(prices: List[float], period: int = 20) -> Dict[str, Optional[float]]:
    """Quick Bollinger Bands calculation"""
    return TechnicalIndicators.calculate_bollinger_bands(prices, period)

def get_moving_averages(prices: List[float], period: int = 20) -> Dict[str, Optional[float]]:
    """Quick Moving Averages calculation"""
    return TechnicalIndicators.calculate_moving_averages(prices, period)

def analyze_prices(prices: List[float], current_price: float) -> Dict:
    """Quick complete analysis"""
    return TechnicalIndicators.analyze_market_data(prices, current_price)